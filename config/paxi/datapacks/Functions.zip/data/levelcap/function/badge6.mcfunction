tag @s remove cap_65
tag @s add cap_75
tellraw @s {"text":"Votre Level Cap est maintenant de 75 !","color":"green"}
team leave @s
team join Badge06 @s