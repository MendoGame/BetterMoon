tag @s remove cap_75
tag @s add cap_85
tellraw @s {"text":"Votre Level Cap est maintenant de 85 !","color":"green"}
team leave @s
team join Badge07 @s