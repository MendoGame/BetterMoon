tag @s remove cap_15
tag @s add cap_25
tellraw @s {"text":"Votre Level Cap est maintenant de 25 !","color":"green"}
team leave @s
team join Badge01 @s