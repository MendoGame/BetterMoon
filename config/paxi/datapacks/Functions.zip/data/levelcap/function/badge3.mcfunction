tag @s remove cap_35
tag @s add cap_45
tellraw @s {"text":"Votre Level Cap est maintenant de 45 !","color":"green"}
team leave @s
team join Badge03 @s