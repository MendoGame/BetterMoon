tag @s remove cap_25
tag @s add cap_35
tellraw @s {"text":"Votre Level Cap est maintenant de 35 !","color":"green"}
team leave @s
team join Badge02 @s