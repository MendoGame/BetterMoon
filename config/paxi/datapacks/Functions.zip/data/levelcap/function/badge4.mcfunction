tag @s remove cap_45
tag @s add cap_55
tellraw @s {"text":"Votre Level Cap est maintenant de 55 !","color":"green"}
team leave @s
team join Badge04 @s