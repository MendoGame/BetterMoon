tag @s remove cap_55
tag @s add cap_65
tellraw @s {"text":"Votre Level Cap est maintenant de 65 !","color":"green"}
team leave @s
team join Badge05 @s