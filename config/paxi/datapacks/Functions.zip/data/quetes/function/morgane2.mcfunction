tag @s remove Morgane1
tag @s add Morgane2
tp @s -34 31 -54 90 0