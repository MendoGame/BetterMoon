tag @s remove Morgane2
tag @s add Morgane3
tp @s -34 14 -54 90 0